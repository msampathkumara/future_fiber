package io.flutter.plugins.custom_webview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
